// ----------------------------------------------------------------
// The contents of this file are distributed under the CC0 license.
// See http://creativecommons.org/publicdomain/zero/1.0/
// ----------------------------------------------------------------

class Main
{
	static void test(NeuralNet learner, String challenge)
	{
		// Load the training data
		String fn = challenge;
		Matrix trainFeatures = new Matrix();
		trainFeatures.loadARFF(fn + "_train_features.arff");
		Matrix trainLabels = new Matrix();
		trainLabels.loadARFF(fn + "_train_labels.arff");
		Vec w = new Vec(trainFeatures.cols()*trainLabels.cols());
		// Train the model, get weights (m and b)
		w=learner.layer1.ordinary_least_squares(trainFeatures, trainLabels, w);
		//System.out.println("Big Vector w has values: ");
		//w.print();
		
		
		
		
		// using generated w to compute Y 
		// Load the test data
		Matrix testFeatures = new Matrix();
		testFeatures.loadARFF(fn + "_test_features.arff");
		Matrix testLabels = new Matrix();
		testLabels.loadARFF(fn + "_test_labels.arff");
		Vec realLabels = new Vec(testLabels.rows());
		realLabels = realLabels.convertVec(testLabels);

		// Matrix testY is used to store generated label values
		Matrix testY = new Matrix(testLabels.rows(),testLabels.cols()); // 506 instance, so corresponding 5Y.  Y = MX + b
		// Given matrix testFeatures and store each instance of X into a Vector[]
		// Initialize
		Vec[] arrayX = new Vec[testFeatures.rows()]; 
		for(int i = 0; i <testFeatures.rows();i++)
		{
			arrayX[i] = new Vec(testFeatures.cols());
		}
		// load values from Matrix testFeatures to arrayX[i]	
		for(int i = 0; i < testFeatures.rows();i++)
		{
			for(int j =0; j< testFeatures.cols();j++)
			{
				arrayX[i].set(j, testFeatures.getvalue(i, j));
			}
		}
		/*
		for(int i = 0; i < testFeatures.rows();i++)
		{
			System.out.println("arrayX[" + i + "] ");
			arrayX[i].print();
			
		}
		*/
		// calculate activate
		// Initialize 
		Matrix[] arrayY = new Matrix[testFeatures.rows()]; 
		for(int i = 0; i < testFeatures.rows();i++)
		{
			arrayY[i] = new Matrix(1,1);
		}
	
		for(int i = 0; i < testFeatures.rows();i++)
		{
			arrayY[i] = learner.layer1.activate(w, arrayX[i]);
		}
		
		
		/*
		for(int i =0; i < testFeatures.rows();i++)
		{
			System.out.println("Y[ " + i +" ]" );
			arrayY[i].print();
		}
		*/
		int index =0;
		Vec testy = new Vec(testY.rows());
		for(int i = 0; i< arrayY.length;i++)
			testy.set(index++, arrayY[i].getvalue(0, 0));
		
		//System.out.println("Vector testy is: ");
		//testy.print();
		//System.out.println("realLabels has size of " + realLabels.size()+ "values:" );
		//realLabels.print();
		//System.out.println("Predicted Y has size of " + testy.size()+ "values: ");
		//testy.print();
		double result = 0.0;
		result = learner.layer1.rootSquareError(realLabels, testy);
		System.out.println("RMSE(Root-mean-square-error) is: " + result);
	}
	
	public static void testLinear(SupervisedLearner learner)
	{
		// Load data
		//String fn = "data/";
		Matrix houseFeatures = new Matrix();
		houseFeatures.loadARFF("housing_features.arff");
		//houseFeatures.print();
		Matrix houseLabels = new Matrix();
		houseLabels.loadARFF("housing_labels.arff");
		Vec houseLabelsVector = new Vec(houseLabels.rows());
		houseLabelsVector.convertVec(houseLabels);
		// Cross-validate the model: 5 iterations with 10 folds
		learner.crossValidation(5, 10, houseFeatures, houseLabels);	
	}
		
	
	public static void testLearner(NeuralNet learner)
	{
		test(learner, "1");
		test(learner, "2");
		test(learner, "3");
		test(learner, "4");
		test(learner, "5");
	}
	

	 
	public static void main(String[] args)
	{
		testLinear(new BaselineLearner());
		testLearner(new NeuralNet());
			
	}
}
