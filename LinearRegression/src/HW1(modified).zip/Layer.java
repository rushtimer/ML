import java.util.*;
import java.io.*;
// Layer is an abstract class used for neural network
// The first assignment is only one layer
	abstract class Layer {
	// member variable "activation" can be accessed by subclasses, like "LayerLiner" class
	protected Vec activation;
	// Constructor ==> input:
	Layer(int inputs, int outputs)
	{
		activation = new Vec(outputs);
	}
	// Calculate activate value
	abstract Matrix activate(Vec weights, Vec x);
}
