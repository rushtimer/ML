import java.util.Random;

class NeuralNet extends SupervisedLearner{
	LayerLinear layer1;
	Vec weightsLayers; 
	Random rand = new Random();
	
	NeuralNet()
	{
		super();
		layer1 = new LayerLinear(13, 1);
		weightsLayers = new Vec(14);
	}
	
	
	@Override
	String name() {
		return "NeuralNet";
	}

	@Override
	void train(Matrix features, Matrix labels) {
		layer1.ordinary_least_squares(features, labels, weightsLayers);
		System.out.println("NeuralNet class: weightsLayers:");
		weightsLayers.print();
	}

	@Override
	Vec predict(Vec x) {
		return layer1.activate(weightsLayers, x).MatrixToVector(layer1.activate(weightsLayers, x));
	}
	

	void testOLS()
	{
		/*Assume M is a matrix of 5*13=65
		x should have 13 rows
		b should have 5 rows 
		The size of weights is 5*13+ 5=70
		since big vector weights containing all M and b
		*/
		Matrix testX = new Matrix(5,13);// 5 instances, each instance has 13 features
		Vec testWeights = new Vec(13*1+1); // assume output labels have 1 value
		
		Vec x = new Vec(testX.rows()*testX.cols());
		Matrix testY = new Matrix(5,1); // 5 instance, so corresponding 5Y.  Y = MX + b
		NeuralNet nn = new NeuralNet();
		
		// step 1: Generate some random weights
		testWeights = testWeights.fillrand(testWeights);
		//System.out.println("testWeights size: " + testWeights.size());
		// step 2: Generate a random feature matrix, X.
		testX = testX.fillMatrix(testX);
		x = x.convertVec(testX);
		
		// step 3: compute a corresponding label matrix, Y.
		// Given matrix X and store each instance of X into a Vector[]
		// Initialize
		Vec[] arrayX = new Vec[testX.rows()]; 
		for(int i = 0; i < testX.rows();i++)
		{
			arrayX[i] = new Vec(testX.cols());
		}
		// load values from Matrix testX to arrayX[i]	
		for(int i = 0; i < testX.rows();i++)
		{
			for(int j =0; j< testX.cols();j++)
			{
				arrayX[i].set(j, testX.getvalue(i, j));
			}
		}
		
		// calculate Y
		// Initialize 
		
		Matrix[] arrayY = new Matrix[testX.rows()]; 
		for(int i = 0; i < testX.rows();i++)
		{
			arrayY[i] = new Matrix(1,1);
		}

		
		for(int i = 0; i < testX.rows();i++)
		{
			arrayY[i] = nn.layer1.activate(testWeights, arrayX[i]);
		}
		/*
		for(int i =0; i < testX.rows();i++)
		{
			System.out.println("Y[ " + i +" ]" );
			arrayY[i].print();
		}
		*/
		// store arraY[i] into a double y[]
		double [] y = new double[arrayY.length];
		for(int i =0; i< arrayY.length;i++)
		{
			y[i] = arrayY[i].getvalue(0, 0);
		}
		// convert double y[] into a Matrix testY
		for(int i =0; i< arrayY.length;i++)
		{
			testY.setMatrix(i, 0, y[i]);
		}

		// step 6
		Vec newWeights = new Vec(testWeights.size());
		newWeights= nn.layer1.ordinary_least_squares(testX, testY, newWeights);
		System.out.println("New weight has size of " + newWeights.size()+ " and values:  ");
		newWeights.print();
		System.out.println("Original weight has size of " + testWeights.size()+ " and values:  ");
		testWeights.print();
		double result = 0.0;
		result = layer1.rootSquareError(newWeights, testWeights);
		System.out.println("Root-squre-error of original weights and generated weights is: " + result);
	}


	private Object activate(Vec w, Matrix x) {
		// TODO Auto-generated method stub
		return null;
	}
}
